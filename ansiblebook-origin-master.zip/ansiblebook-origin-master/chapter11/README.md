# Chapter 11


```
source chapter11.rc
```

This installs python dependencies listed in the `requirements.txt` file into a Python 3 virtualenv. Then it create a VM in VirtualBox with Vagrant and rund the playbook.
