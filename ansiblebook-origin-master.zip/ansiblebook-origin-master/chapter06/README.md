There are no playbooks in this chapter.

You can run the mezzanine-dev.sh script to run Mezzanine in development mode.

The `Vagrantfile` provisions this when you run `vagrant up`.
