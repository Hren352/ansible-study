#!/bin/bash
conda update -n base -c defaults conda
