# base_conda

Ansible role to install miniconda and configure conda envs with yaml files on Mac, Windows, and RedHat-like and Debian-like Linux platforms.

To run it in a centos8 container locally:
```
mol -s centos8
```

Copyright 2021 Bas Meijer
License: MIT
