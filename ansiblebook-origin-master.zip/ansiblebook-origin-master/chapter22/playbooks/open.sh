echo sonarqube
open http://server07:9000/
echo gitea
open http://server06:3000/
echo jenkins
open http://server05:8080/
echo nexus
open http://server04:8081/#browse/browse
