# ansible-runner execution environments

Documentation:

- https://ansible-runner.readthedocs.io/en/latest/standalone.html
- https://ansible-runner.readthedocs.io/en/latest/python_interface.html
- https://ansible-runner.readthedocs.io/en/latest/container.html

Usage ansible in Docker:

```
source ansible-builder-venv.sh
make image or make build
make run
```
