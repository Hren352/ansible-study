# Chapter 13


```
source chapter13.rc
```

This installs python dependencies listed in the `requirements.txt` file into a Python 3 virtualenv.
