# ansible-runner execution environments

Documentation:

- https://ansible-runner.readthedocs.io/en/latest/container.html

Usage ansible-runner in podman:

```
source install.rc
make build
make run
```
